#include <stdio.h>



int notfound(){
    console_log("VC: Command not found!\n", YELLOW);

    return 0;
}